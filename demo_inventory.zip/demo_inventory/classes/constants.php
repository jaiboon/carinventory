<?php

define("HOST","localhost");
define("USER","root");
define("PASS","");
define("DB","car_inventory");

define("DOMAIN","http://localhost/demo_inventory");

?>